-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2024 at 08:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bakerydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` varchar(6) NOT NULL,
  `bank_name` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `bank_name`) VALUES
('BI', 'Bank Islam'),
('BR', 'Bank Rakyat'),
('BSN', 'Bank Simpanan Nasional '),
('MYB', 'MayBank'),
('RHB', 'RHB Bank');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` varchar(6) NOT NULL,
  `cust_name` varchar(60) DEFAULT NULL,
  `cust_password` varchar(60) DEFAULT NULL,
  `cust_address` text DEFAULT NULL,
  `cust_phone` varchar(12) DEFAULT NULL,
  `cust_email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `cust_name`, `cust_password`, `cust_address`, `cust_phone`, `cust_email`) VALUES
('C00000', 'Harith Affendi', '$2y$10$/qvB.HugxhU6Yd/eFnkjo.ojh5NlaxD1UdhA0DcbccQItu9QP.cRG', 'P145 Tali Air 8, Sekichan, Selangor', '010101010101', 'harith29@gmail.com'),
('C00001', 'Ahmad Faris', '$2y$10$ab.5KC2Zq1jV2aGBXWzHIelLFLHDhZ9yuA3lbDvVqwxM8rlLrWNHq', '405, Taman Raub Jaya 6, 27600, Raub, Pahang', '01125743014', 'faris@gmail.com'),
('C00002', 'Ian Miqhael', '$2y$10$XJh3fJkvsULtLJ.lyx9MseDzUOLbsJymSxvTb4W8i3w2MopDV1sOi', '407, Taman Amalina 3, 27600, Raub, Pahang\r\n', '01325843054', 'ian@gmail.com'),
('C00003', 'Zeffri', '$2y$10$n3wB0NM/5TwB1oOzyRvJMekJkllUVNAgTp.HLAkRVE.bmLe3AN2P6', '23A, Raub Continential Resident, 27600, Raub, Pahang\r\n', '0143456788', 'zeff@gmail.com'),
('C27417', 'Irfan Wafi', '$2y$10$nlHmMSp0ts8nl5TDEEnxm.dFwiaOar1eYWeEY0NBEa/lxzjqiJ43W', 'Seksyen 7, Shah Alam, Selangor', '01232323232', 'wafiwafi@gmail.com'),
('C37183', 'Azratul Shahadah', '$2y$10$27OBXYS7S0n/ZjBRsbX3G.t8vgmIyaRu5b8lR/QdJmF0I6xnZiSju', 'Parit 4 Sekinchan Selangor', '010232463645', 'azra@gmail.com'),
('C70900', 'Aisyah', '$2y$10$PYHqytxXGdQahDbdu8PE8e.rpQfWP3x8H.S6NErXiiXJwxaXwXihG', 'test123', '01987042', 'testing@gmail.com'),
('C79490', 'Ahmad', '$2y$10$B.L6/L8TEul2uOTXBWtJluYqDUYK7CmtHh3mIdjwkin76oRai8Jie', 'Seksyen 7, Shah Alam, Selangor', '0101057686', 'ahmad@gmail.com'),
('C95315', 'Syakir Muzaffar', '$2y$10$Nag1ajIl3C63LmwNgcuXwuCjEUxLg/N8ZmlCY27A9SpW08fvNODby', 'Taman Muntiara, Raub, Pahang ', '01010343478', 'itssyakir@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` varchar(6) NOT NULL,
  `emp_name` varchar(60) DEFAULT NULL,
  `emp_email` varchar(30) DEFAULT NULL,
  `emp_password` varchar(60) DEFAULT NULL,
  `emp_phone` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `emp_name`, `emp_email`, `emp_password`, `emp_phone`) VALUES
('ADMINS', 'admin', 'adminBaka', '$2y$10$pdaHYOtHfzfxuVSxYS2EMOP0zyvZFbawcy9AyKuImQIYzGSCjwlA6', 'admin'),
('E00001', 'Ahmad Azib', 'azib@gmail.com', '$2y$10$ETXmYeEEeKI.kVu/cllnRuT/Jmw8VjZlgRFuJjEbSC1T07mh69qC6', '0122447683'),
('E00002', 'Dayangku Balqis', 'balqis@gmail.com', '$2y$10$PO/AKTCKYMDir1X34T.8K.YW3r3CkfuD2LB/oBZE21.4IxPoQfbAK', '0112451283'),
('E00003', 'Hariz Rafie', 'hariz@gmail.com', '$2y$10$gURBTzmXVZYKR6R3rwNZVO5EvdFZhrToGOjNMcwTHRHzaBEb8rEwG', '0122447683'),
('E41662', 'Megat Syakirin Hakimi', 'megat@gmail.com', '$2y$10$aGuBxKrGx/.EP65.ucUvq.mukMqvBjw0V/rzdIfbqY5y7lUlMuZ0K', '0123465789'),
('E50739', 'Sheikh', 'sheikh@gmail.com', '$2y$10$O30UsmO0EnPooHncMjDbn.dI/kCoBlGSfPHxewnzIkWEi8w/alugi', '01034567423'),
('E55010', 'Alia Dania', 'dania@gmail.com', '$2y$10$NxtA1h8a3eVwEKu2SBMGUu.O2GFZaqKSir5ll.oS9UztVy0Vfk36u', '01029476865'),
('E98976', 'Amira Natasha', 'mira@gmail.com', '$2y$10$aPL1QVw7xJIhhRq/FfcIEec5lXl8WwCY29CK2qyTkXYssjz6AU2gK', '0103434567');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `food_id` varchar(6) NOT NULL,
  `food_name` varchar(60) DEFAULT NULL,
  `food_desc` tinytext DEFAULT NULL,
  `food_price` decimal(10,2) DEFAULT NULL,
  `picture` varchar(60) NOT NULL,
  `food_type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`food_id`, `food_name`, `food_desc`, `food_price`, `picture`, `food_type`) VALUES
('1-1', 'Cookies and Cream', 'A variety of ice cream that contain pre-crumbled cookies from Nabisco Oreo brand', 12.00, 'https://i.ibb.co/58PrVb0/cookies-and-cream.jpg', 'dessert'),
('1-2', 'Mint Choc Chip', 'An ice cream flavor composed of mint ice cream with small chocolate chips', 13.00, 'https://i.ibb.co/LCb6TBs/mint-choc-chip.jpg', 'dessert'),
('1-3', 'Caramel Cream', 'Use of caramelized sugar that gives the ice cream a rich, smooth, and creamy texture with a sweet and slightly nutty flavor', 14.00, 'https://i.ibb.co/pP9sHn0/caramel-cream.jpg', 'dessert'),
('2-1', 'Tiramisu', 'An Italian dessert that has layers of coffee-soaked ladyfingers and a cream made from mascarpone, eggs and sugar', 15.00, 'https://i.ibb.co/wMGrL8n/tiramisu-cake.jpg', 'cake'),
('2-2', 'Red Velvet', 'A cocoa-based cake in which using vinegar, baking soda, and buttermilk give the cake a smooth, tightly crumbed texture with a subtle, tangy flavor.', 16.00, 'https://i.ibb.co/Qpgxy64/red-velvet.jpg', 'cake'),
('2-3', 'Burn Cheesecake', 'A dessert consisting of a thick, creamy filling of cheese, eggs, and sugar over a thinner crust with sweet toppings', 17.00, 'https://i.ibb.co/Rz3wRYd/Bask-cheesecake.jpg', 'cake'),
('3-1', 'Choc Chip', 'A sweet baked treat that is recognized by its butter flavor and the inclusion of chocolate chips', 10.00, 'https://i.ibb.co/kxYTJn9/choc-chip-cookies.jpg', 'cookies'),
('3-2', 'Dark Choc Chip', 'A sweet baked treat that is recognized by its butter flavor and the inclusion of dark chocolate chips', 11.00, 'https://i.ibb.co/jLpGPNH/dark-choc-chip.jpg', 'cookies'),
('3-3', 'Vanilla Choc Chip', 'A sweet baked treat that is recognized by its butter flavor and the inclusion of vanilla chocolate chips', 12.00, 'https://i.ibb.co/1RqVVrH/vanilla-choc-chip.jpg', 'cookies');

-- --------------------------------------------------------

--
-- Table structure for table `food_order`
--

CREATE TABLE `food_order` (
  `ord_id` varchar(6) NOT NULL,
  `cust_id` varchar(6) DEFAULT NULL,
  `food_id` varchar(6) DEFAULT NULL,
  `qty` int(10) DEFAULT NULL,
  `ord_status` varchar(60) DEFAULT NULL,
  `emp_id` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food_order`
--

INSERT INTO `food_order` (`ord_id`, `cust_id`, `food_id`, `qty`, `ord_status`, `emp_id`) VALUES
('O03126', 'C37183', '1-3', 2, 'Pending', NULL),
('O09311', 'C00002', '2-3', 2, 'Pending', NULL),
('O1', 'C00000', '1-1', 1, 'Cancelled', 'E50739'),
('O16437', 'C00001', '1-3', 2, 'Pending', NULL),
('O2', 'C00000', '1-2', 2, 'Pending', 'E00001'),
('O21523', 'C27417', '1-3', 2, 'Pending', 'E50739'),
('O48413', 'C37183', '3-1', 5, 'Pending', 'E00002'),
('O67778', 'C00001', '3-2', 2, 'Pending', 'E98976'),
('O70245', 'C37183', '2-2', 3, 'Pending', NULL),
('O89300', 'C27417', '2-1', 2, 'Pending', 'E41662'),
('O91908', 'C00000', '1-2', 2, 'Pending', 'E00003'),
('O97555', 'C27417', '3-3', 3, 'Pending', 'E50739');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `pay_id` varchar(6) NOT NULL,
  `ord_id` varchar(6) DEFAULT NULL,
  `bank_id` varchar(6) DEFAULT NULL,
  `rep_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`pay_id`, `ord_id`, `bank_id`, `rep_date`) VALUES
('P03376', 'O48413', 'BSN', '2024-06-12'),
('P1', 'O1', 'BR', '2024-05-31'),
('P17774', 'O03126', 'BSN', '2024-06-12'),
('P2', 'O2', 'BR', '2024-05-31'),
('P20901', 'O09311', 'MYB', '2024-06-12'),
('P26995', 'O91908', 'BSN', '2024-06-05'),
('P27932', 'O70245', 'BI', '2024-06-12'),
('P30882', 'O67778', 'BI', '2024-06-12'),
('P39028', 'O16437', 'RHB', '2024-06-12'),
('P39961', 'O21523', 'MYB', '2024-06-12'),
('P43274', 'O97555', 'MYB', '2024-06-12'),
('P93287', 'O89300', 'MYB', '2024-06-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`),
  ADD UNIQUE KEY `cust_email` (`cust_email`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`),
  ADD UNIQUE KEY `emp_email` (`emp_email`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `food_order`
--
ALTER TABLE `food_order`
  ADD PRIMARY KEY (`ord_id`),
  ADD KEY `cust_id` (`cust_id`),
  ADD KEY `cake_id` (`food_id`),
  ADD KEY `food_order` (`emp_id`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`pay_id`),
  ADD KEY `ord_id` (`ord_id`),
  ADD KEY `bank_id` (`bank_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `food_order`
--
ALTER TABLE `food_order`
  ADD CONSTRAINT `food_order` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`),
  ADD CONSTRAINT `food_order_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`cust_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `food_order_ibfk_2` FOREIGN KEY (`food_id`) REFERENCES `food` (`food_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `receipt`
--
ALTER TABLE `receipt`
  ADD CONSTRAINT `receipt_ibfk_1` FOREIGN KEY (`ord_id`) REFERENCES `food_order` (`ord_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `receipt_ibfk_2` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
